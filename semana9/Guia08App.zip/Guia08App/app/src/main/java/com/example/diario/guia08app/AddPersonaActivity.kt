package com.example.diario.guia08app

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.diario.guia08app.datos.Persona
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddPersonaActivity : AppCompatActivity() {

    private var txtDUI: EditText? = null
    private var txtNombre: EditText? = null

    private var key = ""
    private var accion = ""

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_persona)

        // Esto te faltaba
        inicializar()
    }

    private fun inicializar() {

        txtNombre = findViewById(R.id.txtNombre)
        txtDUI = findViewById(R.id.txtDUI)

        // Obtener datos enviados desde MainActivity
        val datos = intent.extras

        if (datos != null) {

            key = datos.getString("key", "")
            accion = datos.getString("accion", "")

            txtNombre?.setText(
                datos.getString("nombre", "")
            )

            txtDUI?.setText(
                datos.getString("dui", "")
            )
        }
    }

    fun guardar(v: View?) {

        val nombre = txtNombre?.text.toString().trim()
        val dui = txtDUI?.text.toString().trim()

        // Validar campos
        if (nombre.isEmpty()) {
            txtNombre?.error = "Ingrese un nombre"
            return
        }

        if (dui.isEmpty()) {
            txtDUI?.error = "Ingrese un DUI"
            return
        }

        database = FirebaseDatabase
            .getInstance()
            .getReference("personas")

        // Crear objeto Persona
        val persona = Persona(dui, nombre)

        if (accion == "a") {

            // AGREGAR REGISTRO

            val newKey = database.push().key

            if (newKey != null) {

                // Guardamos también la clave dentro del objeto
                persona.key = newKey

                database
                    .child(newKey)
                    .setValue(persona)
                    .addOnSuccessListener {

                        Toast.makeText(
                            this,
                            "Se guardó con éxito",
                            Toast.LENGTH_SHORT
                        ).show()

                        finish()
                    }
                    .addOnFailureListener {

                        Toast.makeText(
                            this,
                            "Error al guardar",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

            } else {

                Toast.makeText(
                    this,
                    "No se pudo generar una clave",
                    Toast.LENGTH_SHORT
                ).show()
            }

        } else if (accion == "e") {

            // EDITAR REGISTRO

            if (key.isNotEmpty()) {

                persona.key = key

                database
                    .child(key)
                    .setValue(persona)
                    .addOnSuccessListener {

                        Toast.makeText(
                            this,
                            "Se actualizó con éxito",
                            Toast.LENGTH_SHORT
                        ).show()

                        finish()
                    }
                    .addOnFailureListener {

                        Toast.makeText(
                            this,
                            "Error al actualizar",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

            } else {

                Toast.makeText(
                    this,
                    "No se encontró la clave del registro",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun cancelar(v: View?) {
        finish()
    }
}