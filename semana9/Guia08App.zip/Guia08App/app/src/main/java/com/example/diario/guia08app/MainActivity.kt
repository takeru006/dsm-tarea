package com.example.diario.guia08app

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.diario.guia08app.datos.Persona
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    var consultaOrdenada: Query = refPersonas.orderByChild("nombre")
    var personas: MutableList<Persona>? = null
    lateinit var listaPersonas: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inicializar()
    }

    private fun inicializar() {

        val fab_agregar: FloatingActionButton =
            findViewById(R.id.fab_agregar)

        listaPersonas = findViewById(R.id.ListaPersonas)

        // Clic normal sobre una persona para editarla
        listaPersonas.setOnItemClickListener(
            object : AdapterView.OnItemClickListener {

                override fun onItemClick(
                    adapterView: AdapterView<*>?,
                    view: View,
                    i: Int,
                    l: Long
                ) {

                    val intent = Intent(
                        this@MainActivity,
                        AddPersonaActivity::class.java
                    )

                    intent.putExtra("accion", "e")
                    intent.putExtra("key", personas!![i].key)
                    intent.putExtra("nombre", personas!![i].nombre)
                    intent.putExtra("dui", personas!![i].dui)

                    startActivity(intent)
                }
            }
        )

        // Clic largo para eliminar
        listaPersonas.onItemLongClickListener =
            object : AdapterView.OnItemLongClickListener {

                override fun onItemLongClick(
                    adapterView: AdapterView<*>?,
                    view: View,
                    position: Int,
                    l: Long
                ): Boolean {

                    val ad = AlertDialog.Builder(this@MainActivity)

                    ad.setMessage("¿Está seguro de eliminar el registro?")
                        .setTitle("Confirmación")

                        .setPositiveButton("Sí") { dialog, id ->

                            personas!![position].key?.let { key ->

                                refPersonas
                                    .child(key)
                                    .removeValue()
                                    .addOnSuccessListener {

                                        Toast.makeText(
                                            this@MainActivity,
                                            "Registro borrado",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                    .addOnFailureListener {

                                        Toast.makeText(
                                            this@MainActivity,
                                            "Error al borrar",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                            }
                        }

                    ad.setNegativeButton(
                        "No",
                        object : DialogInterface.OnClickListener {

                            override fun onClick(
                                dialog: DialogInterface,
                                id: Int
                            ) {

                                Toast.makeText(
                                    this@MainActivity,
                                    "Operación de borrado cancelada",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    )

                    ad.show()

                    return true
                }
            }

        // Botón para agregar una nueva persona
        fab_agregar.setOnClickListener {

            val i = Intent(
                this@MainActivity,
                AddPersonaActivity::class.java
            )

            i.putExtra("accion", "a")
            i.putExtra("key", "")
            i.putExtra("nombre", "")
            i.putExtra("dui", "")

            startActivity(i)
        }

        // Crear lista vacía
        personas = ArrayList()

        // Leer personas desde Firebase ordenadas por nombre
        consultaOrdenada.addValueEventListener(
            object : ValueEventListener {

                override fun onDataChange(dataSnapshot: DataSnapshot) {

                    personas!!.clear()

                    for (dato in dataSnapshot.children) {

                        val persona =
                            dato.getValue(Persona::class.java)

                        if (persona != null) {

                            // Guardar también la clave del registro Firebase
                            persona.key = dato.key

                            personas!!.add(persona)
                        }
                    }

                    val adapter = AdaptadorPersona(
                        this@MainActivity,
                        personas as ArrayList<Persona>
                    )

                    listaPersonas.adapter = adapter
                }

                override fun onCancelled(
                    databaseError: DatabaseError
                ) {

                    Toast.makeText(
                        this@MainActivity,
                        "Error: ${databaseError.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )
    }

    companion object {

        var database: FirebaseDatabase =
            FirebaseDatabase.getInstance()

        var refPersonas: DatabaseReference =
            database.getReference("personas")
    }
}